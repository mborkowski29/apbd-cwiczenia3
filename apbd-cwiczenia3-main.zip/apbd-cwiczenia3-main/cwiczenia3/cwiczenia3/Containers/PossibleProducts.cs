﻿namespace cwiczenia3.Containers;

public enum PossibleProducts
{
    Banana,
}