﻿namespace cwiczenia3.Interfaces;

public interface IContainer
{
    
}