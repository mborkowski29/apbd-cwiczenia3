﻿namespace cwiczenia3.Interfaces;

public interface IHazardNotifier
{
        void NotifyHazard(string containerNumber);
}